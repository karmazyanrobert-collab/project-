"""Test runner script."""

import subprocess
import sys
from pathlib import Path


def main() -> int:
    """Run pytest with verbose output."""
    project_root = Path(__file__).resolve().parent
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "tests", "-v"],
        cwd=str(project_root),
    )
    return result.returncode


if __name__ == "__main__":
    sys.exit(main())
