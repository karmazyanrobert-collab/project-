# University Data Platform (без Docker)

Демонстрационная локальная Data Platform для университета: ETL/ELT, Lakehouse, Data Quality, Feature Store, Streaming, Semantic Layer и Dashboard.

Проект полностью работает на **Windows** без Docker, WSL, Linux и облачных сервисов.

## Описание

Платформа собирает и обрабатывает данные по трём доменам:

1. **Academic Performance** — студенты, курсы, оценки, задания, академические риски
2. **Student Engagement** — активность в LMS (входы, просмотры, отправка заданий)
3. **Campus Infrastructure** — корпуса, аудитории, события входа/выхода, загрузка помещений

## Архитектура

```
Генерация данных (CSV)
        ↓
Bronze Layer (Parquet, сырые данные)
        ↓
Data Quality Checks
        ↓
Silver Layer (очищенные данные)
        ↓
Data Quality Checks
        ↓
Gold Layer (аналитические таблицы)
        ↓
Feature Store (Parquet)
        ↓
DuckDB Warehouse
        ↓
Semantic Layer (бизнес-метрики)
        ↓
Streamlit Dashboard
        ↓
Streaming Events (JSONL → DuckDB)
```

### Замена enterprise-компонентов

| Enterprise | Локальный аналог |
|---|---|
| S3 / MinIO | `data/bronze`, `data/silver`, `data/gold` |
| Kafka | Файловый event stream (`data/events/event_stream.jsonl`) |
| Airflow | `run_pipeline.py` |
| ClickHouse | DuckDB (`data/warehouse.duckdb`) |
| Grafana | Streamlit Dashboard |
| Feast | Feature Store в Parquet + DuckDB |
| Cube.js | `semantic_layer.py` |
| CI/CD | pytest + `run_tests.py` |

## Стек технологий

- Python 3.11+
- pandas, numpy, pyarrow
- DuckDB
- Streamlit, Plotly
- Faker, APScheduler
- pytest

## Установка

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## Запуск pipeline

```bash
python run_pipeline.py
```

Pipeline выполняет:
1. Создание директорий
2. Генерацию исходных CSV
3. Загрузку в Bronze (Parquet)
4. Data Quality проверки
5. Трансформацию в Silver
6. Повторные DQ проверки
7. Трансформацию в Gold
8. Построение Feature Store
9. Загрузку в DuckDB Warehouse

## Запуск dashboard

```bash
streamlit run dashboard/app.py
```

Dashboard показывает:
- KPI-карточки (студенты, средний балл, риски)
- Графики по факультетам (Plotly)
- Drill-down: факультет → группа → студенты
- Аналитику LMS и аудиторий
- Preview Feature Store
- Streaming metrics (если запущен streaming demo)

## Запуск streaming demo

В отдельном терминале:

```bash
python run_streaming_demo.py
```

Producer генерирует события каждую секунду в `data/events/event_stream.jsonl`.
Consumer читает новые события и обновляет таблицы `streaming_events` и `streaming_metrics` в DuckDB.

## Запуск тестов

```bash
python run_tests.py
```

Тесты проверяют Data Quality framework, Silver-трансформации и Semantic Layer.

## Что показывать на защите

1. **Pipeline** — запустить `python run_pipeline.py`, показать логи каждого шага
2. **Data Quality** — открыть `logs/data_quality_report.csv`, показать FAILED на Bronze и PASSED на Silver
3. **Lakehouse** — показать файлы в `data/bronze`, `data/silver`, `data/gold`
4. **Feature Store** — показать `data/features/student_features.parquet`
5. **DuckDB** — показать таблицы в `data/warehouse.duckdb`
6. **Dashboard** — запустить Streamlit, показать KPI, графики, drill-down
7. **Streaming** — запустить `run_streaming_demo.py`, обновить dashboard, показать live events
8. **Тесты** — запустить `python run_tests.py`, показать что все проходят

## Структура проекта

```
university-data-platform-no-docker/
├── data/                  # Data Lake + Warehouse
├── src/                   # ETL, DQ, Feature Store, Semantic Layer
├── streaming/             # File-based event streaming
├── dashboard/             # Streamlit app
├── tests/                 # pytest tests
├── logs/                  # DQ reports
├── run_pipeline.py        # Main orchestrator
├── run_streaming_demo.py  # Streaming demo
└── run_tests.py           # Test runner
```
